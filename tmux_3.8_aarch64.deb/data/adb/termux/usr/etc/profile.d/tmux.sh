export TMUX_TMPDIR=/data/adb/termux/usr/var/run
